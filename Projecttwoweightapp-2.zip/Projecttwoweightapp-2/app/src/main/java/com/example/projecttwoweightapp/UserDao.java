package com.example.projecttwoweightapp;





import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.projecttwoweightapp.AppDatabase;


public class UserDao {
    private final AppDatabase helper;

    public UserDao(Context ctx) {
        helper = new AppDatabase(ctx);
    }

    public long createUser(String username, String password) throws Exception {
        SQLiteDatabase db = helper.getWritableDatabase();
        if (userExists(username)) {
            throw new Exception("Username already exists");
        }
        ContentValues cv = new ContentValues();
        cv.put("username", username.trim());
        cv.put("password", password);
        return db.insertOrThrow(AppDatabase.T_USERS, null, cv);
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabase.T_USERS, new String[]{"id"},
                "username = ?", new String[]{username.trim()},
                null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public long authenticate(String username, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabase.T_USERS, new String[]{"id"},
                "username = ? AND password = ?", new String[]{username.trim(), password},
                null, null, null);
        long userId = -1;
        if (c.moveToFirst()) userId = c.getLong(0);
        c.close();
        return userId;
    }
}
