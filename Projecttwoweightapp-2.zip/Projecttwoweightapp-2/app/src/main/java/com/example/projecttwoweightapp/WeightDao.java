package com.example.projecttwoweightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class WeightDao {
    private final AppDatabase helper;

    public WeightDao(Context ctx) {
        helper = new AppDatabase(ctx);
    }

    // CREATE - Add new weight for a user
    public void addWeight(int userId, String date, double weight) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("date", date);
        values.put("weight", weight);
        db.insert(AppDatabase.T_WEIGHTS, null, values);
        db.close();
    }

    // READ - Get all weights for a user
    public List<String> getAllWeights(int userId) {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT date, weight FROM " + AppDatabase.T_WEIGHTS +
                " WHERE user_id = ?", new String[]{String.valueOf(userId)});
        if (c.moveToFirst()) {
            do {
                String entry = c.getString(0) + " - " + c.getDouble(1) + " lbs";
                list.add(entry);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    // UPDATE - Update existing weight entry
    public void updateWeight(int id, double newWeight) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight", newWeight);
        db.update(AppDatabase.T_WEIGHTS, values, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // DELETE - Delete weight entry
    public void deleteWeight(int id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.delete(AppDatabase.T_WEIGHTS, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }
}
