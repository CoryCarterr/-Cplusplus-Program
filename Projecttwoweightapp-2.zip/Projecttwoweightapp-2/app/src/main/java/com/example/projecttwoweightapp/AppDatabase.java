package com.example.projecttwoweightapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabase extends SQLiteOpenHelper {
    public static final String DB_NAME = "weightapp.db";
    public static final int DB_VERSION = 1;

    public static final String T_USERS = "users";
    public static final String T_WEIGHTS = "weights";
    public static final String T_GOALS = "goals";

    public AppDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL" +
                ");");

        db.execSQL("CREATE TABLE " + T_WEIGHTS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "date TEXT NOT NULL, " +
                "weight REAL NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES " + T_USERS + "(id)" +
                ");");

        db.execSQL("CREATE TABLE " + T_GOALS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER UNIQUE NOT NULL, " +
                "goal_weight REAL NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES " + T_USERS + "(id)" +
                ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }
}
