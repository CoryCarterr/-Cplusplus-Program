package com.example.projecttwoweightapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class WeightGridActivity extends AppCompatActivity {

    // Existing fields
    private EditText etDate, etWeight;
    private Button btnAdd;
    private ListView listWeights;
    private WeightDao weightDao;

    // 🟢 New Goal Weight fields
    private EditText etGoalWeight;
    private Button btnSetGoal;
    private GoalDao goalDao;
    private long currentUserId = 1; // temporary user for demo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_grid);

        // Link existing components
        etDate = findViewById(R.id.etDate);
        etWeight = findViewById(R.id.etWeight);
        btnAdd = findViewById(R.id.btnAdd);
        listWeights = findViewById(R.id.listWeights);

        // 🟢 Link new Goal components
        etGoalWeight = findViewById(R.id.etGoalWeight);
        btnSetGoal = findViewById(R.id.btnSetGoal);

        // Initialize DAOs
        weightDao = new WeightDao(this);
        goalDao = new GoalDao(this);

        // Show existing weights on load
        refreshList();

        // 🟢 Handle goal weight button click
        btnSetGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalStr = etGoalWeight.getText().toString().trim();
                if (goalStr.isEmpty()) {
                    Toast.makeText(WeightGridActivity.this, "Enter a goal weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                double goalWeight = Double.parseDouble(goalStr);
                goalDao.setGoalWeight(currentUserId, goalWeight);
                Toast.makeText(WeightGridActivity.this, "Goal weight saved!", Toast.LENGTH_SHORT).show();
                etGoalWeight.setText("");
            }
        });

        // Add button logic (for daily weights)
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = etDate.getText().toString().trim();
                String weightText = etWeight.getText().toString().trim();

                if (date.isEmpty() || weightText.isEmpty()) {
                    Toast.makeText(WeightGridActivity.this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                double weight = Double.parseDouble(weightText);
                weightDao.addWeight((int) currentUserId, date, weight);
                double goal = goalDao.getGoalWeight(currentUserId);
                if (goal > 0 && weight <= goal) {
                    Toast.makeText(WeightGridActivity.this, "Goal reached! Sending SMS...", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(WeightGridActivity.this, SmsPermissionActivity.class));
                }
                Toast.makeText(WeightGridActivity.this, "Weight added!", Toast.LENGTH_SHORT).show();

                etDate.setText("");
                etWeight.setText("");

                refreshList();
            }
        });
    }

    // Refresh ListView with all weights for the user
    private void refreshList() {
        List<String> weights = weightDao.getAllWeights((int) currentUserId);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weights);
        listWeights.setAdapter(adapter);
    }
}


