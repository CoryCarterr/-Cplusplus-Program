package com.example.projecttwoweightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class GoalDao {
    private final AppDatabase helper;

    public GoalDao(Context ctx) {
        helper = new AppDatabase(ctx);
    }

    // Create or update goal weight
    public void setGoalWeight(long userId, double goalWeight) {
        SQLiteDatabase db = helper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        int rows = db.update(AppDatabase.T_GOALS, values, "user_id=?", new String[]{String.valueOf(userId)});
        if (rows == 0) {
            db.insert(AppDatabase.T_GOALS, null, values);
        }

        db.close();
    }

    // Retrieve goal weight for a user
    public double getGoalWeight(long userId) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabase.T_GOALS, new String[]{"goal_weight"}, "user_id=?",
                new String[]{String.valueOf(userId)}, null, null, null);

        double goal = -1;
        if (c.moveToFirst()) {
            goal = c.getDouble(0);
        }
        c.close();
        db.close();
        return goal;
    }
}
